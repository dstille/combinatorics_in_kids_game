STORY = """
game description
"""
ALLPLAYERS = ['list all the players for your game here'.split()]
APLAYERS = ALLPLAYERS[:4]
BPLAYERS = ALLPLAYERS[4:]

AND = ' and '
NUM_ERROR = 'Not a number. Please try again'
STR_ERROR = 'Error processing input! Please try again'
PERFECT = 'ON THE NOSE!!!'
IN = 'in'
AFFIRM = 'yes'

PROMPT_USER_OPTIONS = 'would you like to type in a lot of stuff or have the computer decide who plays, (y/n)? '
PROMPT_APLAYERS_TO_PLAY = 'enter the aplayers to play, separated by a space: '
PROMPT_APLAYERS_NUM = 'enter the number of aplayers to choose: '
PROMPT_BPLAYERS_TO_PLAY = 'enter the bplayers to play, separated by a space: '
PROMPT_BPLAYERS_NUM = 'enter the number of players to choose: '
PROMPT_PLAYERS_TO_CHECK_ODDS_FOR = 'enter the players to check the odds that they got chosen, separated by a space: '

PROMPT_ODDS = 'Enter the odds or probability that %s will be chosen.\nFor odds enter __ in __ ; for probability enter _.__ : '

DISPLAY_APLAYERS_NUM_CHOSEN = 'The number of aplayers chosen is'
DISPLAY_APLAYERS = 'and the aplayers targets are '
DISPLAY_BPLAYERS_NUM_CHOSEN = 'The number of bplayers chosen is'
DISPLAY_BPLAYERS = 'and the bplayers targets are'
DISPLAY_PLAYERS_TO_CHECK_ODDS_FOR = 'We are going to check the odds that %s got chosen'

DISPLAY_QUERIED_ASETS= 'queried aplayers subsets:   '
DISPLAY_ASETS = 'aplayers sets:               '
DISPLAY_QUERIED_BSETS = 'queried bplayers subsets:     '
DISPLAY_BSETS = 'bplayers sets:                 '
DISPLAY_QUERIED_COMBINED_SETS = 'combined queried subsets:  '
DISPLAY_COMINED_SETS = 'combined sets:            '

CONGRATS = 'You did it!!!'
TOO_BAD = 'Not quite'
RESULTS_ODDS = 'the odds were'
RESULTS_PROB = 'or a probability of'
SETS = 'sets'
CONTINUE = 'Would you like another go, (y/n)?: '